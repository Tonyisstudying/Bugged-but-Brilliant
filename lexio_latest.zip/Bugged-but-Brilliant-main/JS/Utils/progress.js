export default class ProgressTracker {
    saveProgress(stageId, exerciseId, score) {
        // Save progress logic
    }

    getProgress(stageId) {
        // Get progress logic
    }
}